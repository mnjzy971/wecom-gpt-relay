# WeCom GPT Relay

这是一个简化版的企业微信 GPT 中转服务部署模板，适用于 Vercel 免费部署。
